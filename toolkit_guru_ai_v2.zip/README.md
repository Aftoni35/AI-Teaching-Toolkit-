# Toolkit AI untuk Guru Bahasa Inggris — Aftoni Ilman Huda

**Versi 2.0** — Fokus penuh untuk audiens guru non-tech-savvy.

## Apa yang Berubah dari Versi Sebelumnya

- **Audiens dipersempit**: dari "portofolio prompt engineering" menjadi "toolkit praktis untuk guru Bahasa Inggris" — bahasa diparafrase agar lebih mengundang, tidak terdengar teknis.
- **Desain dirombak total**: dari dark glassmorphism generik menjadi tema "ruang kelas hangat" (kertas, papan tulis hijau tua, kapur, tinta merah) — supaya guru merasa ini "dunia mereka", bukan dunia developer.
- **Panduan visual ditambahkan**: panah hand-drawn dan anotasi untuk membantu navigasi pengguna yang kurang familiar dengan teknologi.
- **Semua tombol kini benar-benar berfungsi**: copy-to-clipboard nyata (dengan fallback), filter, expand/collapse, tab switching.
- **3 Alat Bantu baru**:
  1. Cek Level CEFR Murid (mini quiz 4 pertanyaan)
  2. Racik Prompt Sendiri (form generator prompt RPP otomatis)
  3. Panduan Singkat AI di Kelas (etika penggunaan, bisa disalin)
- **Sistem Komentar Publik**: guru bisa memberi rating bintang + komentar, tampil ke semua pengunjung, tersimpan permanen.
- **Section "Cara Pakai"**: 3 langkah super sederhana sebelum masuk ke koleksi prompt.

## Struktur File

```
index.html          — Halaman utama
css/style.css        — Semua styling (tema kelas hangat, responsive)
js/main.js            — Data prompt, interaksi, quiz CEFR, customizer, sistem komentar
README.md             — Dokumen ini
```

## Catatan Teknis Penting

### Penyimpanan Komentar
Kode menggunakan `window.storage` (API penyimpanan Claude Artifacts) jika tersedia, dan otomatis jatuh ke `localStorage` browser sebagai fallback saat dideploy sebagai situs statis biasa (misalnya di Genspark, Netlify, Vercel, GitHub Pages, dll).

**Penting:** jika dideploy sebagai HTML statis biasa, `localStorage` bersifat per-browser/per-perangkat, BUKAN benar-benar publik lintas semua pengunjung dunia. Untuk komentar yang benar-benar tersimpan di server dan terlihat semua orang dari perangkat manapun, dibutuhkan backend sederhana (misalnya Firebase, Supabase, atau Google Sheets sebagai database) — ini di luar lingkup file statis ini dan perlu pengembangan tambahan jika dibutuhkan.

### Font & Ikon
Memakai Google Fonts (Lora, Source Sans 3, IBM Plex Mono, Caveat) dan Font Awesome 6 via CDN. Pastikan domain berikut tidak diblokir saat hosting: `fonts.googleapis.com`, `fonts.gstatic.com`, `cdnjs.cloudflare.com`.

## Cara Deploy Ulang ke Genspark (atau platform lain)

1. Unduh seluruh folder ini.
2. Upload ulang ketiga file (`index.html`, `css/style.css`, `js/main.js`) dengan struktur folder yang sama ke platform hosting Anda.
3. Pastikan path relatif (`css/style.css`, `js/main.js`) tetap terjaga strukturnya.

---
*Oleh Aftoni Ilman Huda · Proyek Mandiri · 2026*
