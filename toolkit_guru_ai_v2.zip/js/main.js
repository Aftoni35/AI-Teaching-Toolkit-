/* =========================================================
   PROMPT TEMPLATE DATA
   ========================================================= */
const PROMPTS = [
  {
    id: "vocab",
    category: "vocabulary",
    badgeLevel: "B1 - Menengah",
    title: "Pembuat Latihan Vocabulary Kontekstual",
    desc: "Buat latihan kosakata yang langsung dipakai dalam kalimat nyata, bukan sekadar daftar kata hafalan.",
    prompt: `Berperanlah sebagai guru ESL/EFL berpengalaman yang menyusun materi vocabulary untuk murid level [LEVEL MURID].

Tugas Anda: buat latihan vocabulary kontekstual untuk kata-kata berikut:

Kata target: [DAFTAR 5-8 KATA]
Tema/konteks: [contoh: "rutinitas harian di kantor", "isu lingkungan"]
Level murid: [contoh: B1 menengah]
Jenis latihan: [contoh: isian rumpang, mencocokkan, melengkapi kalimat]

Untuk setiap kata, sertakan:
1. Definisi sederhana yang mudah dipahami murid
2. Satu kalimat contoh sesuai konteks
3. Satu kalimat isian rumpang (jawaban dipisah)
4. Kata pasangan yang sering muncul bersamanya (collocation)

Pastikan semua kalimat contoh konsisten dengan tema yang diberikan. Gunakan bahasa yang jelas dan alami sesuai level murid.`,
    output: `<h4>Latihan Vocabulary: Isu Lingkungan (Level B1)</h4>
<p><strong>1. Sustainable</strong><br>
<em>Definisi:</em> Mampu berlanjut dalam waktu lama tanpa merusak lingkungan atau menghabiskan sumber daya.<br>
<em>Contoh:</em> Many companies are switching to sustainable packaging to reduce plastic waste.<br>
<em>Isian rumpang:</em> We need to find ________ solutions to our energy problems. <em>(jawaban: sustainable)</em><br>
<em>Pasangan kata:</em> sustainable development / energy / farming</p>
<p><strong>2. Emission</strong><br>
<em>Definisi:</em> Gas atau zat lain yang dilepaskan ke udara, biasanya oleh mesin atau pabrik.<br>
<em>Contoh:</em> The government set a target to reduce carbon emissions by 40% before 2030.<br>
<em>Isian rumpang:</em> Electric vehicles produce no direct ________. <em>(jawaban: emissions)</em><br>
<em>Pasangan kata:</em> carbon emissions / reduce emissions / emission targets</p>
<p><strong>3. Biodiversity</strong><br>
<em>Definisi:</em> Keragaman tumbuhan, hewan, dan makhluk hidup lain di suatu tempat atau di bumi.<br>
<em>Contoh:</em> Cutting down forests leads to a serious loss of biodiversity.<br>
<em>Isian rumpang:</em> The national park was created to protect local ________. <em>(jawaban: biodiversity)</em><br>
<em>Pasangan kata:</em> protect biodiversity / biodiversity loss / rich biodiversity</p>`,
    rationale: `<div class="rationale-note"><strong>Kenapa disusun begini?</strong> Penelitian tentang pemerolehan bahasa kedua menunjukkan murid lebih mudah mengingat kosakata saat ditemukan dalam konteks yang bermakna, bukan daftar kata terpisah.</div>
<ul>
<li><strong>Peran "guru berpengalaman"</strong> membuat AI menggunakan nada dan istilah yang sesuai untuk kelas, bukan bahasa teknis kamus.</li>
<li><strong>Placeholder/variabel</strong> membuat prompt ini bisa dipakai ulang untuk topik dan level apa pun, tinggal ganti bagian dalam kurung siku.</li>
<li><strong>Struktur 4 bagian</strong> (definisi, contoh, isian, pasangan kata) mendorong pemahaman kata yang lebih dalam, bukan sekadar mengenal artinya.</li>
</ul>`
  },
  {
    id: "lesson",
    category: "lesson",
    badgeLevel: "Semua Level",
    title: "Pembuat RPP Komunikatif",
    desc: "RPP lengkap dengan tujuan pembelajaran, aktivitas, dan alokasi waktu yang siap dipakai mengajar.",
    prompt: `Anda adalah perancang kurikulum Bahasa Inggris profesional. Buat RPP (Rencana Pelaksanaan Pembelajaran) komunikatif yang detail berdasarkan rincian berikut:

Topik: [TOPIK]
Level: [Level CEFR, contoh: A2, B1]
Durasi: [contoh: 60 menit]
Profil murid: [contoh: murid SMP kelas 8, dewasa kursus privat]
Fokus keterampilan utama: [Speaking / Listening / Reading / Writing / Gabungan]
Poin tata bahasa (opsional): [contoh: present perfect]

RPP harus mencakup:
1. Tujuan pembelajaran (3 hasil yang bisa diukur)
2. Kegiatan pembuka/pemanasan (5-10 menit)
3. Tahap penyampaian materi dengan kegiatan guru dan murid secara detail
4. Latihan terbimbing (controlled practice)
5. Latihan bebas/komunikatif (production)
6. Penutup dan refleksi
7. Alat/bahan yang diperlukan
8. Catatan diferensiasi untuk murid yang lebih cepat/lambat

Gunakan kerangka PPP (Presentation-Practice-Production) dan sertakan alokasi waktu di setiap tahap.`,
    output: `<h4>RPP: Memberi Arah Jalan (Level B1, 60 menit)</h4>
<table>
<tr><th>Tahap</th><th>Aktivitas</th><th>Waktu</th></tr>
<tr><td>Pemanasan</td><td>Murid melihat gambar peta kota. Guru bertanya: "Pernah tersesat? Apa yang kamu lakukan?" Diskusi singkat.</td><td>7 menit</td></tr>
<tr><td>Penyampaian</td><td>Guru memperkenalkan frasa arah kunci (belok kiri/kanan, jalan terus) menggunakan peta yang diproyeksikan.</td><td>10 menit</td></tr>
<tr><td>Latihan Terbimbing</td><td>Latihan listening: murid mengikuti arah di lembar kerja peta dan menandai tujuan.</td><td>12 menit</td></tr>
<tr><td>Latihan Bebas</td><td>Role-play berpasangan: murid A (turis) bertanya arah, murid B (warga lokal) menjawab dengan peta. Bertukar peran.</td><td>20 menit</td></tr>
<tr><td>Penutup</td><td>Satu murid memberi arah dari memori. Kelas menilai kejelasannya.</td><td>8 menit</td></tr>
<tr><td>Refleksi</td><td>Guru mengoreksi pola kesalahan umum. Murid mencatat 3 frasa baru di jurnal kosakata.</td><td>3 menit</td></tr>
</table>
<p><strong>Bahan:</strong> Lembar peta kota, klip audio, papan tulis, jurnal kosakata</p>
<p><strong>Diferensiasi:</strong> Murid lebih cepat menambahkan landmark; murid yang butuh bantuan ekstra memakai peta sederhana dengan lebih sedikit belokan.</p>`,
    rationale: `<div class="rationale-note"><strong>Kenapa disusun begini?</strong> Prompt ini berlandaskan prinsip Communicative Language Teaching (CLT) yang mengutamakan interaksi bermakna sebagai inti pembelajaran bahasa.</div>
<ul>
<li><strong>Hasil yang bisa diukur</strong> memastikan RPP bisa dievaluasi, bukan hanya daftar kegiatan.</li>
<li><strong>Catatan diferensiasi</strong> mencerminkan praktik mengajar inklusif — mengakui bahwa satu kelas berisi murid dengan kecepatan belajar berbeda.</li>
<li><strong>Permintaan detail di setiap tahap</strong> mencegah AI menghasilkan RPP generik yang sulit langsung dipakai.</li>
</ul>`
  },
  {
    id: "reading",
    category: "reading",
    badgeLevel: "Multi-level",
    title: "Pembuat Teks Bacaan Berjenjang",
    desc: "Teks bacaan sesuai level murid lengkap dengan soal pemahaman dan kunci jawaban.",
    prompt: `Anda adalah penulis materi untuk penerbit buku EFL. Tulis teks bacaan berjenjang beserta soal pemahamannya berdasarkan brief berikut:

Topik: [TOPIK]
Level CEFR: [contoh: B2]
Jumlah kata: [contoh: 300-350 kata]
Jenis teks: [artikel / narasi / laporan / blog post]
Vocabulary target: [5 kata yang harus muncul alami dalam teks]

Persyaratan:
1. Tulis teks dengan memasukkan semua kata target secara alami
2. Sesuaikan kompleksitas kalimat dan kosakata dengan level CEFR yang diminta
3. Sertakan 4 soal pemahaman: 1 literal, 1 inferensial, 1 vocabulary-in-context, 1 opini/refleksi
4. Sertakan kunci jawaban untuk soal 1-3
5. Tambahkan satu pertanyaan diskusi pasca-membaca untuk dipakai di kelas`,
    output: `<h4>Teks Bacaan: Bekerja dari Rumah (Level B2)</h4>
<p>Over the past decade, the landscape of work has undergone a profound transformation. What began as a flexible arrangement for a small number of professionals has become a mainstream model across industries worldwide. The COVID-19 pandemic served as a powerful catalyst, forcing organizations to adapt at unprecedented speed.</p>
<p>Remote work offers clear advantages: greater autonomy, reduced commuting costs, and improved work-life balance. However, the model is not without challenges — social isolation and the blurring of professional and personal boundaries remain genuine concerns, especially for younger employees who may miss informal mentoring.</p>
<p><strong>Soal Pemahaman:</strong></p>
<ol>
<li><em>(Literal)</em> Peristiwa apa yang mempercepat penerapan kerja jarak jauh?</li>
<li><em>(Inferensial)</em> Mengapa kerja jarak jauh bisa merugikan karyawan baru secara khusus?</li>
<li><em>(Vocabulary)</em> Apa arti kata "catalyst" pada paragraf pertama?</li>
<li><em>(Opini)</em> Menurut Anda, apakah model kerja hybrid adalah solusi ideal? Jelaskan.</li>
</ol>
<p><strong>Kunci jawaban:</strong> 1. Pandemi COVID-19. 2. Mereka kehilangan kesempatan mentoring informal. 3. Sesuatu yang mempercepat terjadinya perubahan.</p>`,
    rationale: `<div class="rationale-note"><strong>Kenapa disusun begini?</strong> Prompt ini memakai prinsip extensive reading — bahasa dipelajari lewat teks bermakna yang sesuai level, bukan latihan tata bahasa lepas konteks.</div>
<ul>
<li><strong>Kalibrasi level CEFR</strong> memastikan teks pada titik kesulitan yang pas — tidak terlalu mudah maupun membebani.</li>
<li><strong>4 jenis soal</strong> mencerminkan tingkatan berpikir dari mengingat hingga mengevaluasi.</li>
<li><strong>Vocabulary dimasukkan secara alami</strong> (bukan dipaksakan) sehingga murid menemui kata target dalam wacana yang autentik.</li>
</ul>`
  },
  {
    id: "assessment",
    category: "assessment",
    badgeLevel: "Fleksibel",
    title: "Perancang Soal Penilaian Formatif",
    desc: "Soal evaluasi berjenjang HOTS lengkap dengan rubrik penilaian yang jelas.",
    prompt: `Anda adalah spesialis penilaian bahasa Inggris. Rancang tugas penilaian formatif berdasarkan parameter berikut:

Keterampilan yang dinilai: [contoh: speaking, writing, reading]
Poin bahasa: [contoh: modal verbs untuk memberi saran, kalimat kondisional]
Level murid: [Level CEFR]
Format tugas: [contoh: role-play, esai pendek, koreksi kesalahan]
Batas waktu: [contoh: 10-15 menit]

Sertakan:
1. Instruksi tugas yang jelas untuk murid (bahasa yang dipahami murid)
2. Fokus penilaian: fitur bahasa spesifik apa yang akan diamati
3. Rubrik analitik sederhana (4 kriteria x 4 level)
4. Catatan guru: kesalahan umum yang perlu diwaspadai
5. Contoh kalimat feedback yang bisa dipakai guru setelah tugas selesai`,
    output: `<h4>Penilaian Formatif: Memberi Saran (Modal Verbs) — Speaking B1</h4>
<p><strong>Instruksi Murid:</strong> Temanmu merasa gugup menjelang ujian penting. Dalam 2 menit, beri minimal 3 saran. Gunakan kata seperti "should," "could," "might want to," dan "if I were you."</p>
<table>
<tr><th>Kriteria</th><th>4 - Sangat Baik</th><th>3 - Baik</th><th>2 - Berkembang</th><th>1 - Perlu Bimbingan</th></tr>
<tr><td>Penggunaan Modal</td><td>3+ struktur modal dipakai akurat & alami</td><td>2-3 modal, sedikit kesalahan</td><td>1-2 modal, kurang akurat</td><td>Jarang/salah pakai modal</td></tr>
<tr><td>Relevansi</td><td>Semua saran relevan & dijelaskan</td><td>Sebagian besar relevan</td><td>Beberapa saran kurang jelas</td><td>Saran tidak relevan</td></tr>
<tr><td>Kelancaran</td><td>Nyaris tanpa keraguan, alami</td><td>Sedikit ragu tapi tetap lancar</td><td>Sering ragu</td><td>Sangat tersendat</td></tr>
<tr><td>Vocabulary</td><td>Kaya dan variatif</td><td>Cukup, sedikit repetisi</td><td>Terbatas</td><td>Tidak cukup untuk tugas</td></tr>
</table>
<p><strong>Kesalahan umum:</strong> Tertukar "should" (saran) dengan "must" (wajib); subjek hilang pada kondisional ("If were you" seharusnya "If I were you").</p>`,
    rationale: `<div class="rationale-note"><strong>Kenapa disusun begini?</strong> Prompt ini berdasarkan prinsip Assessment for Learning — penilaian dipakai untuk memperbaiki proses belajar, bukan hanya mengukur hasil akhir.</div>
<ul>
<li><strong>Instruksi berbahasa murid</strong> membuat guru bisa langsung memakainya di kelas tanpa menulis ulang.</li>
<li><strong>Rubrik analitik</strong> memisahkan dimensi bahasa berbeda, memberi feedback yang lebih presisi.</li>
<li><strong>Catatan kesalahan umum</strong> membantu guru tahu apa yang harus diperhatikan saat tugas berlangsung.</li>
</ul>`
  },
  {
    id: "writing",
    category: "writing",
    badgeLevel: "Menengah Atas+",
    title: "Perancang Tugas Menulis Berjenjang",
    desc: "Tugas menulis lengkap dengan teks model, kerangka rencana, dan checklist evaluasi diri murid.",
    prompt: `Anda adalah instruktur academic writing yang menyusun materi untuk kelas EFL. Buat rangkaian tugas menulis berjenjang untuk penugasan berikut:

Jenis tulisan: [contoh: esai argumentatif, email, laporan, narasi]
Topik: [TOPIK]
Level murid: [B2/C1]
Target jumlah kata: [contoh: 250-300 kata]
Konteks: [contoh: kelas academic writing, persiapan tes]

Rangkaian harus mencakup:
1. Tugas pengenalan genre: teks model dengan label struktur (hook, thesis, isi, penutup)
2. Kotak fokus bahasa: 5-6 frasa/pembuka kalimat berguna untuk jenis teks ini
3. Kerangka perencanaan: pertanyaan pemandu sebelum menulis
4. Instruksi tugas menulis lengkap untuk murid
5. Checklist evaluasi diri (5-6 poin) yang diisi murid setelah menulis`,
    output: `<h4>Tugas Menulis Berjenjang: Esai Argumentatif (B2)</h4>
<p><strong>Teks Model Beranotasi:</strong></p>
<p>[HOOK] In an age where technology permeates every aspect of our daily lives, the debate over whether social media does more harm than good has never been more relevant.<br>
[THESIS] While social media offers undeniable benefits, its negative effects on mental health outweigh its advantages.<br>
[ISI - Argumen 1] First and foremost, excessive social media use has been linked to increased rates of anxiety...<br>
[PENUTUP] In conclusion, the evidence strongly suggests that society must adopt a more critical relationship with social media platforms.</p>
<p><strong>Kotak Fokus Bahasa:</strong></p>
<ul>
<li>It is widely argued that… / A common view is that…</li>
<li>While … undoubtedly …, it is important to consider…</li>
<li>Opponents of this view claim that… / However, this argument fails to account for…</li>
</ul>
<p><strong>Checklist Evaluasi Diri:</strong></p>
<ul>
<li>☐ Apakah esai saya punya hook dan thesis statement yang jelas?</li>
<li>☐ Apakah saya menyertakan satu counter-argument dan rebuttal?</li>
<li>☐ Apakah setiap paragraf isi fokus pada satu ide utama?</li>
<li>☐ Apakah penutup saya merangkum tanpa ide baru?</li>
</ul>`,
    rationale: `<div class="rationale-note"><strong>Kenapa disusun begini?</strong> Prompt ini dibangun dari Genre-Based Pedagogy dan Process Writing — murid dipandu lewat kesadaran genre, perencanaan, menulis, lalu refleksi.</div>
<ul>
<li><strong>Teks model beranotasi</strong> menunjukkan struktur secara eksplisit, bukan berharap murid menyerapnya sendiri.</li>
<li><strong>Kotak fokus bahasa</strong> memberi dukungan frasa formal yang sering sulit diakses murid EFL.</li>
<li><strong>Checklist evaluasi diri</strong> melatih kesadaran metakognitif murid terhadap tulisannya sendiri.</li>
</ul>`
  }
];

/* =========================================================
   RENDER PROMPT CARDS
   ========================================================= */
const promptListEl = document.getElementById("promptList");

function escapeHtml(str) {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function renderPromptHtml(promptText) {
  const escaped = escapeHtml(promptText);
  return escaped.replace(/\[([^\]]+)\]/g, '<span class="var">[$1]</span>');
}

function renderPrompts() {
  promptListEl.innerHTML = PROMPTS.map((p, i) => `
    <div class="prompt-card reveal in-view" data-category="${p.category}" data-id="${p.id}">
      <div class="pc-head" data-toggle="${p.id}">
        <div class="pc-left">
          <div class="pc-num">${String(i + 1).padStart(2, "0")}</div>
          <div>
            <div class="pc-badges">
              <span class="badge">${p.category}</span>
              <span class="badge level">${p.badgeLevel}</span>
            </div>
            <div class="pc-title">${p.title}</div>
            <div class="pc-desc">${p.desc}</div>
          </div>
        </div>
        <div class="pc-chevron"><i class="fa-solid fa-chevron-down"></i></div>
      </div>
      <div class="pc-body">
        <div class="pc-tabs">
          <button class="pc-tab active" data-tab="prompt" data-card="${p.id}">Prompt</button>
          <button class="pc-tab" data-tab="output" data-card="${p.id}">Contoh Hasil</button>
          <button class="pc-tab" data-tab="rationale" data-card="${p.id}">Kenapa Begini?</button>
        </div>
        <div class="pc-panel active" data-panel="prompt" data-card="${p.id}">
          <div class="prompt-box">${renderPromptHtml(p.prompt)}</div>
          <button class="copy-btn" data-copy="${p.id}"><i class="fa-regular fa-copy"></i> Salin Prompt Ini</button>
        </div>
        <div class="pc-panel" data-panel="output" data-card="${p.id}">
          <div class="output-md">${p.output}</div>
        </div>
        <div class="pc-panel" data-panel="rationale" data-card="${p.id}">
          <div class="output-md">${p.rationale}</div>
        </div>
      </div>
    </div>
  `).join("");
}
renderPrompts();

/* Expand/collapse */
promptListEl.addEventListener("click", (e) => {
  const head = e.target.closest(".pc-head");
  if (head) {
    const card = head.closest(".prompt-card");
    card.classList.toggle("expanded");
    return;
  }
  const tab = e.target.closest(".pc-tab");
  if (tab) {
    const cardId = tab.dataset.card;
    const tabName = tab.dataset.tab;
    document.querySelectorAll(`.pc-tab[data-card="${cardId}"]`).forEach(t => t.classList.remove("active"));
    document.querySelectorAll(`.pc-panel[data-card="${cardId}"]`).forEach(p => p.classList.remove("active"));
    tab.classList.add("active");
    document.querySelector(`.pc-panel[data-panel="${tabName}"][data-card="${cardId}"]`).classList.add("active");
    return;
  }
  const copyBtn = e.target.closest(".copy-btn[data-copy]");
  if (copyBtn) {
    const promptObj = PROMPTS.find(p => p.id === copyBtn.dataset.copy);
    copyToClipboard(promptObj.prompt, copyBtn);
  }
});

/* Filter chips */
const filterRow = document.getElementById("filterRow");
filterRow.addEventListener("click", (e) => {
  const chip = e.target.closest(".filter-chip");
  if (!chip) return;
  filterRow.querySelectorAll(".filter-chip").forEach(c => c.classList.remove("active"));
  chip.classList.add("active");
  const filter = chip.dataset.filter;
  document.querySelectorAll(".prompt-card").forEach(card => {
    if (filter === "all" || card.dataset.category === filter) {
      card.classList.remove("hidden-card");
    } else {
      card.classList.add("hidden-card");
    }
  });
});

/* =========================================================
   COPY TO CLIPBOARD (with fallback) + TOAST
   ========================================================= */
function showToast(msg, icon = "fa-circle-check") {
  const toast = document.getElementById("toast");
  toast.innerHTML = `<i class="fa-solid ${icon}"></i> ${msg}`;
  toast.classList.add("show");
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}

function copyToClipboard(text, btnEl) {
  const done = (ok) => {
    if (!btnEl) return;
    const original = btnEl.innerHTML;
    if (ok) {
      btnEl.innerHTML = '<i class="fa-solid fa-check"></i> Tersalin!';
      btnEl.classList.add("copied");
      showToast("Prompt berhasil disalin. Sekarang buka aplikasi AI Anda dan tempel di sana.");
    } else {
      showToast("Gagal menyalin otomatis. Silakan salin teks secara manual.", "fa-triangle-exclamation");
    }
    setTimeout(() => {
      btnEl.innerHTML = original;
      btnEl.classList.remove("copied");
    }, 2200);
  };

  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(() => done(true)).catch(() => fallbackCopy(text, done));
  } else {
    fallbackCopy(text, done);
  }
}

function fallbackCopy(text, cb) {
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    document.body.removeChild(ta);
    cb(ok);
  } catch (err) {
    cb(false);
  }
}

/* =========================================================
   NAVBAR: scroll state, mobile toggle, active link
   ========================================================= */
const navbar = document.getElementById("navbar");
const navToggle = document.getElementById("navToggle");
const navLinks = document.getElementById("navLinks");

window.addEventListener("scroll", () => {
  navbar.classList.toggle("scrolled", window.scrollY > 10);
  backToTopBtn.classList.toggle("show", window.scrollY > 500);
}, { passive: true });

navToggle.addEventListener("click", () => {
  navLinks.classList.toggle("mobile-open");
});
navLinks.querySelectorAll("a").forEach(a => {
  a.addEventListener("click", () => navLinks.classList.remove("mobile-open"));
});

/* Active link highlight on scroll */
const sections = ["cara-pakai", "prompts", "tools", "feedback", "about"];
const navAnchors = Array.from(navLinks.querySelectorAll("a[href^='#']"));
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      navAnchors.forEach(a => a.classList.remove("active"));
      const match = navAnchors.find(a => a.getAttribute("href") === "#" + entry.target.id);
      if (match) match.classList.add("active");
    }
  });
}, { rootMargin: "-40% 0px -50% 0px" });
sections.forEach(id => {
  const el = document.getElementById(id);
  if (el) observer.observe(el);
});

/* =========================================================
   BACK TO TOP
   ========================================================= */
const backToTopBtn = document.getElementById("backToTop");
backToTopBtn.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));

/* =========================================================
   SCROLL REVEAL
   ========================================================= */
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("in-view");
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
document.querySelectorAll(".reveal").forEach(el => revealObserver.observe(el));

/* =========================================================
   CEFR LEVEL FINDER (mini quiz)
   ========================================================= */
const cefrQuestions = [
  {
    q: "Saat membaca teks asing, murid Anda bisa...",
    opts: [
      { text: "Mengenal kata-kata sangat dasar dan kalimat sederhana", score: 1 },
      { text: "Memahami ide utama teks sehari-hari dengan kosakata familiar", score: 2 },
      { text: "Memahami artikel dan laporan tentang topik yang cukup kompleks", score: 3 },
      { text: "Memahami teks panjang dan kompleks termasuk makna implisit", score: 4 }
    ]
  },
  {
    q: "Saat berbicara, murid Anda mampu...",
    opts: [
      { text: "Menjawab pertanyaan sangat sederhana dengan kata/frasa pendek", score: 1 },
      { text: "Bercerita pengalaman sehari-hari dengan kalimat sederhana", score: 2 },
      { text: "Berdiskusi dan menjelaskan pendapat dengan cukup lancar", score: 3 },
      { text: "Berbicara spontan dan lancar hampir tanpa mencari kata", score: 4 }
    ]
  },
  {
    q: "Dalam menulis, murid Anda biasanya...",
    opts: [
      { text: "Menulis kalimat sangat pendek dengan banyak kesalahan dasar", score: 1 },
      { text: "Menulis paragraf sederhana tentang hal yang familiar", score: 2 },
      { text: "Menulis esai terstruktur dengan argumen yang jelas", score: 3 },
      { text: "Menulis teks kompleks dengan gaya yang fleksibel dan tepat", score: 4 }
    ]
  },
  {
    q: "Tata bahasa (grammar) murid Anda...",
    opts: [
      { text: "Masih banyak kesalahan dasar bahkan di kalimat sederhana", score: 1 },
      { text: "Cukup akurat untuk situasi familiar, sering salah di luar itu", score: 2 },
      { text: "Cukup akurat dengan variasi struktur kalimat yang baik", score: 3 },
      { text: "Sangat akurat dan konsisten bahkan di struktur kompleks", score: 4 }
    ]
  }
];

const cefrLevelMap = {
  4: { level: "A1", desc: "Pemula — fokuskan pada kosakata dasar dan kalimat sangat sederhana." },
  5: { level: "A2", desc: "Dasar — murid sudah bisa kalimat sederhana tentang hal sehari-hari." },
  6: { level: "A2", desc: "Dasar — murid sudah bisa kalimat sederhana tentang hal sehari-hari." },
  7: { level: "B1", desc: "Menengah — murid bisa berkomunikasi untuk kebutuhan sehari-hari dan topik familiar." },
  8: { level: "B1", desc: "Menengah — murid bisa berkomunikasi untuk kebutuhan sehari-hari dan topik familiar." },
  9: { level: "B1", desc: "Menengah — murid bisa berkomunikasi untuk kebutuhan sehari-hari dan topik familiar." },
  10: { level: "B2", desc: "Menengah Atas — murid sudah cukup mandiri dalam berbagai topik." },
  11: { level: "B2", desc: "Menengah Atas — murid sudah cukup mandiri dalam berbagai topik." },
  12: { level: "B2", desc: "Menengah Atas — murid sudah cukup mandiri dalam berbagai topik." },
  13: { level: "C1", desc: "Mahir — murid bisa menggunakan bahasa secara fleksibel dan efektif." },
  14: { level: "C1", desc: "Mahir — murid bisa menggunakan bahasa secara fleksibel dan efektif." },
  15: { level: "C1", desc: "Mahir — murid bisa menggunakan bahasa secara fleksibel dan efektif." },
  16: { level: "C2", desc: "Sangat Mahir — murid memahami hampir semua hal yang didengar/dibaca." }
};

let cefrCurrentQ = 0;
let cefrScore = 0;

const cefrStartBtn = document.getElementById("cefrStartBtn");
const cefrTool = document.getElementById("cefrTool");
const cefrQuestionsEl = document.getElementById("cefrQuestions");
const cefrResultEl = document.getElementById("cefrResult");

cefrStartBtn.addEventListener("click", () => {
  cefrTool.classList.add("active");
  cefrCurrentQ = 0;
  cefrScore = 0;
  cefrResultEl.classList.remove("show");
  renderCefrQuestion();
  cefrStartBtn.style.display = "none";
});

function renderCefrQuestion() {
  if (cefrCurrentQ >= cefrQuestions.length) {
    showCefrResult();
    return;
  }
  const q = cefrQuestions[cefrCurrentQ];
  cefrQuestionsEl.innerHTML = `
    <div class="cefr-q">Pertanyaan ${cefrCurrentQ + 1}/${cefrQuestions.length}: ${q.q}</div>
    <div class="cefr-options">
      ${q.opts.map((o, i) => `<button class="cefr-opt" data-score="${o.score}">${o.text}</button>`).join("")}
    </div>
  `;
  cefrQuestionsEl.querySelectorAll(".cefr-opt").forEach(btn => {
    btn.addEventListener("click", () => {
      cefrScore += parseInt(btn.dataset.score, 10);
      cefrCurrentQ++;
      renderCefrQuestion();
    });
  });
}

function showCefrResult() {
  cefrQuestionsEl.innerHTML = "";
  const result = cefrLevelMap[cefrScore] || cefrLevelMap[4];
  document.getElementById("cefrLevel").textContent = result.level;
  document.getElementById("cefrDesc").textContent = result.desc;
  cefrResultEl.classList.add("show");
}

document.getElementById("cefrRestart").addEventListener("click", (e) => {
  e.preventDefault();
  cefrCurrentQ = 0;
  cefrScore = 0;
  cefrResultEl.classList.remove("show");
  renderCefrQuestion();
});

/* =========================================================
   PROMPT CUSTOMIZER
   ========================================================= */
document.getElementById("pczGenerateBtn").addEventListener("click", () => {
  const topic = document.getElementById("pczTopic").value.trim() || "[isi topik pelajaran Anda]";
  const level = document.getElementById("pczLevel").value;
  const duration = document.getElementById("pczDuration").value;

  const generated = `Anda adalah perancang kurikulum Bahasa Inggris profesional. Buat RPP komunikatif yang detail berdasarkan rincian berikut:

Topik: ${topic}
Jenjang: ${level}
Durasi: ${duration}
Fokus keterampilan: Gabungan (Listening, Speaking, Reading, Writing)

RPP harus mencakup:
1. Tujuan pembelajaran (3 hasil yang bisa diukur)
2. Kegiatan pembuka/pemanasan
3. Tahap penyampaian materi dengan kegiatan guru dan murid secara detail
4. Latihan terbimbing
5. Latihan bebas/komunikatif
6. Penutup dan refleksi
7. Alat/bahan yang diperlukan
8. Catatan diferensiasi untuk murid yang lebih cepat/lambat

Gunakan kerangka PPP (Presentation-Practice-Production) dan sertakan alokasi waktu di setiap tahap. Tulis dalam format yang langsung siap dipakai mengajar.`;

  const outputEl = document.getElementById("pczOutput");
  outputEl.textContent = generated;
  outputEl.style.display = "block";
  document.getElementById("pczCopyBtn").style.display = "inline-flex";
  window._pczGenerated = generated;
});

document.getElementById("pczCopyBtn").addEventListener("click", (e) => {
  copyToClipboard(window._pczGenerated || "", e.currentTarget);
});

/* =========================================================
   GUIDE COPY BUTTON
   ========================================================= */
/* =========================================================
   STORAGE COMPATIBILITY LAYER
   Uses window.storage when available (Claude artifact environment).
   Falls back to localStorage when deployed as a static site.
   ========================================================= */
const Store = {
  async get(key, shared) {
    if (window.storage && typeof window.storage.get === "function") {
      try { return await window.storage.get(key, shared); }
      catch (err) { return null; }
    }
    const raw = localStorage.getItem(key);
    return raw ? { key, value: raw, shared: !!shared } : null;
  },
  async set(key, value, shared) {
    if (window.storage && typeof window.storage.set === "function") {
      try { return await window.storage.set(key, value, shared); }
      catch (err) { return null; }
    }
    localStorage.setItem(key, value);
    return { key, value, shared: !!shared };
  }
};

/* =========================================================
   FEEDBACK / PUBLIC COMMENTS SYSTEM (shared storage)
   ========================================================= */
const commentsListEl = document.getElementById("commentsList");
const feedbackForm = document.getElementById("feedbackForm");
const fbMsgEl = document.getElementById("fbMsg");
const fbStarsEl = document.getElementById("fbStars");
let fbSelectedStars = 0;

fbStarsEl.querySelectorAll(".fb-star").forEach(star => {
  star.addEventListener("click", () => {
    fbSelectedStars = parseInt(star.dataset.val, 10);
    updateStarDisplay();
  });
  star.addEventListener("mouseenter", () => {
    const hoverVal = parseInt(star.dataset.val, 10);
    fbStarsEl.querySelectorAll(".fb-star").forEach(s => {
      s.classList.toggle("active", parseInt(s.dataset.val, 10) <= hoverVal);
    });
  });
});
fbStarsEl.addEventListener("mouseleave", updateStarDisplay);

function updateStarDisplay() {
  fbStarsEl.querySelectorAll(".fb-star").forEach(s => {
    s.classList.toggle("active", parseInt(s.dataset.val, 10) <= fbSelectedStars);
  });
}

function timeAgo(timestamp) {
  const diff = Date.now() - timestamp;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "Baru saja";
  if (mins < 60) return `${mins} menit lalu`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} jam lalu`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days} hari lalu`;
  return new Date(timestamp).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" });
}

function initials(name) {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[1][0]).toUpperCase();
}

function renderComments(comments) {
  if (!comments.length) {
    commentsListEl.innerHTML = `<div class="comments-empty"><i class="fa-regular fa-comment-dots" style="font-size:28px; margin-bottom:10px; display:block; opacity:0.5;"></i>Belum ada komentar. Jadilah guru pertama yang membagikan pengalaman Anda!</div>`;
    return;
  }
  const sorted = [...comments].sort((a, b) => b.timestamp - a.timestamp);
  commentsListEl.innerHTML = sorted.map(c => `
    <div class="comment-card">
      <div class="comment-top">
        <div class="comment-author">
          <div class="comment-avatar">${escapeHtml(initials(c.name))}</div>
          <div>
            <div class="comment-name">${escapeHtml(c.name)}</div>
            ${c.role ? `<div class="comment-role">${escapeHtml(c.role)}</div>` : ""}
          </div>
        </div>
        <div class="comment-stars">${"★".repeat(c.stars)}${"☆".repeat(5 - c.stars)}</div>
      </div>
      <div class="comment-text">${escapeHtml(c.comment)}</div>
      <div class="comment-date">${timeAgo(c.timestamp)}</div>
    </div>
  `).join("");
}

async function loadComments() {
  try {
    const result = await Store.get("teacher-toolkit-comments", true);
    const comments = result && result.value ? JSON.parse(result.value) : [];
    renderComments(comments);
    return comments;
  } catch (err) {
    renderComments([]);
    return [];
  }
}

async function saveComment(newComment) {
  let comments = [];
  try {
    const result = await Store.get("teacher-toolkit-comments", true);
    comments = result && result.value ? JSON.parse(result.value) : [];
  } catch (err) {
    comments = [];
  }
  comments.push(newComment);
  await Store.set("teacher-toolkit-comments", JSON.stringify(comments), true);
  return comments;
}

feedbackForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const name = document.getElementById("fbName").value.trim();
  const role = document.getElementById("fbRole").value.trim();
  const comment = document.getElementById("fbComment").value.trim();

  fbMsgEl.classList.remove("show", "success", "error");

  if (!name || !comment) {
    fbMsgEl.textContent = "Mohon isi nama dan komentar Anda.";
    fbMsgEl.classList.add("show", "error");
    return;
  }
  if (fbSelectedStars === 0) {
    fbMsgEl.textContent = "Mohon beri penilaian bintang terlebih dahulu.";
    fbMsgEl.classList.add("show", "error");
    return;
  }

  const submitBtn = feedbackForm.querySelector("button[type=submit]");
  const originalText = submitBtn.textContent;
  submitBtn.textContent = "Mengirim...";
  submitBtn.disabled = true;

  try {
    const newComment = {
      name, role, comment,
      stars: fbSelectedStars,
      timestamp: Date.now()
    };
    const updated = await saveComment(newComment);
    renderComments(updated);
    fbMsgEl.textContent = "Terima kasih! Komentar Anda sudah tampil di bawah.";
    fbMsgEl.classList.add("show", "success");
    feedbackForm.reset();
    fbSelectedStars = 0;
    updateStarDisplay();
    showToast("Komentar berhasil dikirim. Terima kasih atas masukannya!");
  } catch (err) {
    fbMsgEl.textContent = "Gagal mengirim komentar. Silakan coba lagi.";
    fbMsgEl.classList.add("show", "error");
  } finally {
    submitBtn.textContent = originalText;
    submitBtn.disabled = false;
  }
});

loadComments();

